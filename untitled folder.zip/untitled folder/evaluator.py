# Group Name: SYDN 28
# Group Members: 4
# Name: MISHOK SAHA - ID S398552
# Name: Md FAYSAL AHMED - ID S400482
# Name: DOREEN DEE - ID S400212
# Name: ABDULLA KHAN - ID S111111


def format_number(n):
    if n == int(n):
        return str(int(n))
    return str(round(n, 4))


def tokenize(expr):
    tokens = []
    i = 0

    while i < len(expr):
        ch = expr[i]

        if ch.isspace():
            i += 1

        elif ch.isdigit() or ch == ".":
            num = ""
            dot = 0

            while i < len(expr) and (expr[i].isdigit() or expr[i] == "."):
                if expr[i] == ".":
                    dot += 1
                    if dot > 1:
                        return "ERROR"
                num += expr[i]
                i += 1

            if num == ".":
                return "ERROR"

            tokens.append(("NUM", float(num)))

        elif ch in "+-*/":
            tokens.append(("OP", ch))
            i += 1

        elif ch == "(":
            tokens.append(("LPAREN", ch))
            i += 1

        elif ch == ")":
            tokens.append(("RPAREN", ch))
            i += 1

        else:
            return "ERROR"

    tokens.append(("END", ""))
    return tokens

def tokens_to_string(tokens):
    if tokens == "ERROR":
        return "ERROR"

    result = ""
    for t, v in tokens:
        if t == "NUM":
            result += f"[NUM:{format_number(v)}] "
        elif t == "OP":
            result += f"[OP:{v}] "
        elif t == "LPAREN":
            result += f"[LPAREN:(] "
        elif t == "RPAREN":
            result += f"[RPAREN:)] "
        elif t == "END":
            result += "[END]"

    return result.strip()


index = 0


def current(tokens):
    return tokens[index]


def eat(tokens, t=None, v=None):
    global index
    token = tokens[index]

    if t and token[0] != t:
        raise Exception

    if v and token[1] != v:
        raise Exception

    index += 1
    return token


def factor(tokens):
    token = current(tokens)

    if token[0] == "OP" and token[1] == "-":
        eat(tokens, "OP", "-")
        return ("neg", factor(tokens))

    elif token[0] == "LPAREN":
        eat(tokens, "LPAREN", "(")
        node = expression(tokens)
        eat(tokens, "RPAREN", ")")
        return node

    elif token[0] == "NUM":
        return ("num", eat(tokens, "NUM")[1])

    else:
        raise Exception


def term(tokens):
    node = factor(tokens)

    while True:
        token = current(tokens)

        if token[0] == "OP" and token[1] in ["*", "/"]:
            op = eat(tokens, "OP")[1]
            node = (op, node, factor(tokens))

        elif token[0] in ["NUM", "LPAREN"]:
            node = ("*", node, factor(tokens))  # implicit *

        else:
            break

    return node


def expression(tokens):
    node = term(tokens)

    while current(tokens)[0] == "OP" and current(tokens)[1] in ["+", "-"]:
        op = eat(tokens, "OP")[1]
        node = (op, node, term(tokens))

    return node


def tree_to_string(node):
    if node[0] == "num":
        return format_number(node[1])

    if node[0] == "neg":
        return f"(neg {tree_to_string(node[1])})"

    return f"({node[0]} {tree_to_string(node[1])} {tree_to_string(node[2])})"



def calculate(node):
    if node[0] == "num":
        return node[1]

    if node[0] == "neg":
        return -calculate(node[1])

    a = calculate(node[1])
    b = calculate(node[2])

    if node[0] == "+": return a + b
    if node[0] == "-": return a - b
    if node[0] == "*": return a * b
    if node[0] == "/":
        if b == 0:
            raise Exception
        return a / b


# ---------- MAIN PROCESS ----------
def process(line):
    tokens = tokenize(line)

    if tokens == "ERROR":
        return {"input": line, "tree": "ERROR", "tokens": "ERROR", "result": "ERROR"}

    global index
    index = 0

    try:
        tree = expression(tokens)

        if current(tokens)[0] != "END":
            raise Exception

        result = calculate(tree)

        if result == int(result):
            result = int(result)
        else:
            result = round(result, 4)

        return {
            "input": line,
            "tree": tree_to_string(tree),
            "tokens": tokens_to_string(tokens),
            "result": result
        }

    except:
        return {"input": line, "tree": "ERROR", "tokens": "ERROR", "result": "ERROR"}


def evaluate_file(path):
    results = []

    with open(path, "r") as f:
        for line in f:
            line = line.strip()
            if line:
                results.append(process(line))

    with open("output.txt", "w") as f:
        for r in results:
            f.write(f"Input: {r['input']}\n")
            f.write(f"Tree: {r['tree']}\n")
            f.write(f"Tokens: {r['tokens']}\n")
            f.write(f"Result: {r['result']}\n\n")

    return results


if __name__ == "__main__":
    evaluate_file("sample_input.txt")
    print("Done")